import React from "react";

const Home = () => {
  return (
    <section id="img">
      <img
        src="https://t3.ftcdn.net/jpg/01/60/98/14/360_F_160981431_Sw2es2PV5t5kUqITmrA1VomMdvdd7g3P.jpg"
        alt=""
      />
    </section>
  );
};

export default Home;
