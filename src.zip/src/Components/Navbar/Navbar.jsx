import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
    return (
      <section id="navbar">
        <article>
          <div id="logo">
            <Link to="/">Students CRUD</Link>
          </div>
          <div id="menu">
            <a href="">Login</a>
          </div>
        </article>
      </section>
    );
};

export default Navbar;
